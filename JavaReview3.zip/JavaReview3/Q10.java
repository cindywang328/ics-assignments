package JavaReview3;
import java.util.Scanner;
public class Q10 
{
		public static void main(String[] args)
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Integer? ");
			int y = sc.nextInt();

			
			while (leastFactor(y) != 0)
			{
				while(y > 1)
				{
					int f = leastFactor(y);
					System.out.print(f + " ");
					y = y / f;
				}			
				System.out.println("Next Integer? ");
				y = sc.nextInt();	
			}
		}
		public static int leastFactor(int n)
		{
			if(n <= 1)
			{
				return 0;
			}
			
			for(int i = 2; i<=n; i++)
			{
				if(n % i == 0)
				{
					return i;
				}
			}
			return 0;
		
		}

}
