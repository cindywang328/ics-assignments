package JavaReview3;
import java.util.Scanner;
public class Q1 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("number?");
		double x = sc.nextDouble();
		System.out.println("2nd number? ");
		double y = sc.nextDouble();
		
		System.out.println(Math.exp(y * Math.log(x)));
		System.out.println(Math.pow(x, y));
		
	}

}
