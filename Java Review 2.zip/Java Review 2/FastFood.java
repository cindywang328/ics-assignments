package JavaReview2;
import java.util.Scanner;
public class FastFood 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int c = 0;
		System.out.println("Burger choice? ");
		int n = sc.nextInt();
		
		switch(n)
		{
			case 1: c = 461;
			break;
			case 2: c = 431;
			break;
			case 3: c = 420;
			break;
		}
		
		System.out.println("Drink choice?");
		n = sc.nextInt();
		
		switch(n)
		{
			case 1: c = c+130;
			break;
			case 2: c = c+160;
			break;
			case 3: c = c+118;
			break;
		}
		
		System.out.println("Side order choice?");
		n = sc.nextInt();
		switch(n)
		{
			case 1: c = c+100;
			break;
			case 2: c = c+57;
			break;
			case 3: c = c+70;
			break;
		}
		
		System.out.println("Dessert choice?");
		n = sc.nextInt();
		switch(n)
		{
			case 1: c = c+167;
			break;
			case 2: c = c+266;
			break;
			case 3: c = c+75;
			break;
		}
		
		System.out.println("Total calories: " + c);
	}

}
