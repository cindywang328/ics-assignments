package JavaReview2;

import java.util.Scanner;
public class PackageCheck 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner (System.in);
		System.out.print("Weight in kg? ");
		double weight = sc.nextDouble();
		System.out.print("Length in cm? ");
		double l = sc.nextDouble();
		System.out.print("Width in cm? ");
		double w = sc.nextDouble();
		System.out.print("Height in cm? ");
		double h = sc.nextDouble();
		
		boolean heavy = false;
		String output = "";

		if(weight > 27)
		{
			heavy = true;
			output = "Too heavy.";
		}
		if((l*w*h > 100000) && heavy)
		{
			output = "Too heavy and too large.";
		}
		else if (l*w*h > 100000)
		{
			output = "Too large.";
		}
		
		System.out.println(output);
	
		
		
	}

}
