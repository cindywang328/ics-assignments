package JavaReview2;
import java.util.Scanner;
public class Asterisks 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the numbers, separated by spaces:");
		String s = sc.nextLine();
		String[] n = s.split(" ");
		
		for (int i = 0; i< n.length; i++)
		{
			int j = Integer.parseInt(n[i]);
			System.out.print(n[i]);
			
			for(int k = 0; k<j; k++)
			{
				System.out.print("*");
			}
			
			System.out.println("");
		}
		
	}

}
