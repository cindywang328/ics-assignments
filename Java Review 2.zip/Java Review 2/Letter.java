package JavaReview2;
import java.util.Scanner;
public class Letter 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Mass of letter in grams? ");;
		double w = sc.nextDouble();
		
		double cost = 0;
		
		if(w>100)
		{
			if((w-100) % 50 == 0)
			{
			cost = 70 + (w-100)/50 * 25;
			}
			else
			{
			cost = 70 + ((int)((w-100)/50) + 1) * 25;
			}
			
		}
		else if (w>50)
		{
			cost = 70;
		}
		else if (w>30)
		{
			cost = 55;
		}
		else 
		{
			cost = 40;
		}
		
		System.out.println(cost);
	}

}
