package JavaReview2;
import java.util.Scanner;
public class Power2 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Positive integer? ");
		int n = sc.nextInt();
		
		double x = Math.log(n)/Math.log(2);
		
		if(x == Math.floor(x))
		{
			System.out.println(Math.pow(2,  x));
		}
		else
		{
			System.out.println(Math.pow(2, Math.floor(x)+1));
		}
		
	}

}
