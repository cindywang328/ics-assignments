package JavaReview2;

public class WellOrder 
{
	public static void main(String[] args)
	{
		System.out.println("The 3-digit well ordered numbers are:");
		int c = 1;
		for(int i=100; i<=999; i++)
		{
			int h = i/100;
			int t = i/10 - 10*h;
			int o = i - 10*t - 100*h;
			
			if(h < t && t < o)
			{
				if(c % 8 == 0 && c != 0)
				{
					System.out.println(i + " ");
				}
				else
				{
					System.out.print(i + " ");
				}
				c++;
			}
		}
		
		System.out.println("\n" + "total: " + (c-1));
	}

}
