package JavaReview2;
import java.util.Scanner;
public class CarRecall 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Model number?");
		int n = sc.nextInt();
		if (n== 119||n ==179||n==189||n==195||n==221||n==780)
		{
			System.out.println("Your car is defective. It must be repaired.");
		}
		else
		{
			System.out.println("Your car is not defective.");
		}
	}
	

}
