package JavaReview4;
import java.util.Scanner;
public class Q3 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("#rows? ");
		int r = sc.nextInt();
		int[][] n = new int[r][r];
		
		for(int i = 0; i<r; i++)
		{
			
			for(int j = 0; j < r; j++)
			{
				if(i == 0 && j == 0)
				{
					n[i][j] = 1;
				}
				else if (j == 0 || j == i)
				{
					n[i][j] = i + 1;
				}

				else if (i != 0)
				{
					n[i][j] = n[i-1][j-1] + n[i-1][j];
				}

			}
		}
		
		for(int i = 0; i<r; i++)
		{
			
			for(int j = 0; j < r; j++)
			{
				if(n[i][j] != 0)
				{
					if(j < i)
					{
						System.out.print(n[i][j] + " ");
					}
					else
					{
						System.out.println(n[i][j]);
					}
				}
			}
		}
				
	}

}
