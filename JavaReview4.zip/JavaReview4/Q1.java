package JavaReview4;
import java.util.Scanner;
public class Q1
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("numbers separated by spaces? ");
		String[] n = (sc.nextLine()).split(" ");
		int[] numbers = new int[n.length];
		for (int i = 0; i<n.length; i++)
		{
			numbers[i] = Integer.parseInt(n[i]);
		}
		
		System.out.println(zero(numbers) + " " + product(numbers) + " " + sum(numbers) +" "+ min(numbers));
		
	}
	
	public static int zero(int[] x)
	{
		int z = 0;
		for(int i = 0; i<x.length; i++)
		{
			if(x[i] == 0)
			{
				z = z+1;
			}
		}
		return z;
	}
	
	public static int product(int[] x)
	{
		int p = 1;
		for(int i = 0; i<x.length; i++)
		{
			p = p * x[i];
		}
		return p;
		
	}
	
	public static int sum(int[] x)
	{
		int s = 0;
		for(int i = 0; i<x.length; i++)
		{
			s = s + x[i];
		}
		return s;
	}
	
	public static int min(int[] x)
	{
		int m = x[0];
		for(int i = 1; i<x.length; i++)
		{
			if(x[i] < m)
			{
				m = x[i];
			}
		}
		return m;
		
	}
}
