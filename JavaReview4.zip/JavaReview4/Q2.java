package JavaReview4;
import java.util.Scanner;
public class Q2 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("#rows? ");
		int r = sc.nextInt();
		System.out.println("#columns? ");
		int c = sc.nextInt();
		int[][] n = new int[r][c];
		
// enter numbers into the 2D array
		for(int i = 0; i<n.length; i++)
		{	
		for(int j = 0; j < n[0].length; j++)
			{
				System.out.println("Next number?");
			n[i][j] = sc.nextInt();
			}
		}
		
		System.out.println(numberOfElements(n) + " " + sum(n) + " "+ multiplesOf3(n) + " " + range(n));
		

	}
	
	public static int numberOfElements(int[][] x)
	{
		return x.length * x[0].length;
	}
	
	public static int sum(int[][] x)
	{
		int s = 0;
		for(int i = 0; i<x.length; i++)
		{
			
			for(int j = 0; j < x[0].length; j++)
			{
				s = s + x[i][j];
			}
		}
		return s;
	}
	
	public static int multiplesOf3(int[][] x)
	{
		int m = 0;
		for(int i = 0; i<x.length; i++)
		{
			
			for(int j = 0; j < x[0].length; j++)
			{
				if(x[i][j] % 3 == 0)
				{
					m = m + 1;
				}
			}
		}
		return m;
	}
	
	public static int range(int[][] x)
	{
		int min = x[0][0];
		int max = x[0][0];
		
		for(int i = 0; i<x.length; i++)
		{
			
			for(int j = 0; j < x[0].length; j++)
			{
				if(x[i][j] < min)
				{
					min = x[i][j];
				}
				else if (x[i][j] > max)
				{
					max = x[i][j];
				}
			}
		}
		
		return max - min;
	}
	

}

