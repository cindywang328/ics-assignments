package JavaReview4;
import java.util.Scanner;
public class Q4 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("#rows? ");
		int rows = sc.nextInt();
		System.out.println("#columns? ");
		int columns = sc.nextInt();
		String[] field = new String[rows+2];
		int[][] numbers = new int[rows+2][columns+2];
		
		System.out.println("enter . * ");
		for(int i = 0; i<rows+1; i++)
		{
			field[i] = sc.nextLine();
		}
		
		for (int i = 1; i < rows+ 1; i++)
		{
			for(int j = 1; j < columns + 1; j++)
			{
				if (field[i].substring(j-1, j).equals("*"))
				{
				numbers[i-1][j-1] += 1;
				numbers[i-1][j] += 1;
				numbers[i-1][j+1] += 1;
				numbers[i][j+1]+= 1;
				numbers[i][j-1] += 1;
				numbers[i+1][j-1] += 1;
				numbers[i+1][j] += 1;
				numbers[i+1][j+1] += 1;
				
				numbers[i][j] = -10;
				}
			}
		}
		
		for(int i = 1; i< rows + 1; i++)
		{
			
			for(int j = 1; j < columns + 1; j++)
			{
			
				if(j == columns)
					{
						if(numbers[i][j] >= 0)
						{
							System.out.println(numbers[i][j]);
						}
						else
						{
							System.out.println("*");
						}
					}
					else
					{
						if(numbers[i][j] < 0)
						{
							System.out.print("*");
						}
						else
						{
							System.out.print(numbers[i][j]);
						}
					}
				}
			}
		}
	}


